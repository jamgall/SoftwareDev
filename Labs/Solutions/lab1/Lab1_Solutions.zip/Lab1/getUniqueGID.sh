#!/bin/bash

wc -l tmp
